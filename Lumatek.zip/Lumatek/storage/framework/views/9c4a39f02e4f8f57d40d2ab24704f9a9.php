<?php $__env->startSection('title', 'Invernaderos'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title">Invernaderos</h1>
        <p class="page-subtitle">Administración de áreas, cultivos y rangos operativos.</p>
    </div>
    <a class="btn btn-primary" href="<?php echo e(route('greenhouses.create')); ?>">+ Registrar invernadero</a>
</div>

<div class="dashboard-grid">
    <?php $__empty_1 = true; $__currentLoopData = $greenhouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $greenhouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="card span-6">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title"><?php echo e($greenhouse->name); ?></h2>
                    <p class="card-subtitle"><?php echo e($greenhouse->code); ?> · <?php echo e($greenhouse->crop_type ?: 'Cultivo no definido'); ?></p>
                </div>
                <span class="badge <?php echo e($greenhouse->status === 'active'
                        ? 'badge-success'
                        : ($greenhouse->status === 'maintenance' ? 'badge-warning' : 'badge-neutral')); ?>">
                    <?php echo e(ucfirst($greenhouse->status)); ?>

                </span>
            </div>

            <div class="table-wrap">
                <table class="table">
                    <tbody>
                        <tr><th>Ubicación</th><td><?php echo e($greenhouse->location ?: '—'); ?></td></tr>
                        <tr><th>Responsable</th><td><?php echo e($greenhouse->responsible?->name ?: '—'); ?></td></tr>
                        <tr><th>Última temperatura</th><td><?php echo e($greenhouse->latestReading?->temperature ?? '—'); ?> °C</td></tr>
                        <tr><th>Última humedad</th><td><?php echo e($greenhouse->latestReading?->soil_humidity ?? '—'); ?> %</td></tr>
                        <tr><th>Riego automático</th><td><?php echo e($greenhouse->automatic_irrigation ? 'Activado' : 'Desactivado'); ?></td></tr>
                    </tbody>
                </table>
            </div>

            <div class="form-actions">
                <a class="btn btn-ghost" href="<?php echo e(route('dashboard', ['greenhouse_id' => $greenhouse->id])); ?>">Abrir</a>
                <a class="btn btn-secondary" href="<?php echo e(route('greenhouses.edit', $greenhouse)); ?>">Editar</a>
                <form method="POST" action="<?php echo e(route('greenhouses.destroy', $greenhouse)); ?>" data-confirm="¿Eliminar <?php echo e($greenhouse->name); ?> y todos sus datos?">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit">Eliminar</button>
                </form>
            </div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <article class="card span-12 empty-state">No hay invernaderos registrados.</article>
    <?php endif; ?>
</div>

<?php echo e($greenhouses->links('partials.pagination')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/greenhouses/index.blade.php ENDPATH**/ ?>