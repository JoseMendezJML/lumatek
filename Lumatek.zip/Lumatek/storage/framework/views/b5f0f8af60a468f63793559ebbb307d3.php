<?php $__env->startSection('title', 'Reglas de alerta'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title">Reglas de alerta</h1>
        <p class="page-subtitle">Umbrales configurables usados al procesar cada lectura.</p>
    </div>
    <span class="data-source-badge">Motor de reglas</span>
</div>

<div class="dashboard-grid">
    <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="card span-6">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title"><?php echo e($rule->name); ?></h2>
                    <p class="card-subtitle">
                        Variable: <?php echo e(str_replace('_', ' ', $rule->variable)); ?>

                        <?php echo e($rule->greenhouse ? '· '.$rule->greenhouse->name : '· Regla global'); ?>

                    </p>
                </div>
                <span class="badge <?php echo e($rule->severity === 'critical'
                        ? 'badge-critical'
                        : ($rule->severity === 'warning' ? 'badge-warning' : 'badge-info')); ?>">
                    <?php echo e(ucfirst($rule->severity)); ?>

                </span>
            </div>

            <form method="POST" action="<?php echo e(route('alert-rules.update', $rule)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-grid">
                    <div class="field field-third">
                        <label for="severity-<?php echo e($rule->id); ?>">Severidad</label>
                        <select class="select" id="severity-<?php echo e($rule->id); ?>" name="severity">
                            <option value="info" <?php if($rule->severity === 'info'): echo 'selected'; endif; ?>>Información</option>
                            <option value="warning" <?php if($rule->severity === 'warning'): echo 'selected'; endif; ?>>Advertencia</option>
                            <option value="critical" <?php if($rule->severity === 'critical'): echo 'selected'; endif; ?>>Crítica</option>
                        </select>
                    </div>

                    <div class="field field-third">
                        <label for="operator-<?php echo e($rule->id); ?>">Operador</label>
                        <select class="select" id="operator-<?php echo e($rule->id); ?>" name="operator">
                            <?php $__currentLoopData = [
                                'lt' => 'Menor que',
                                'lte' => 'Menor o igual',
                                'gt' => 'Mayor que',
                                'gte' => 'Mayor o igual',
                                'between' => 'Entre',
                                'outside' => 'Fuera de rango',
                                'equals' => 'Igual a texto',
                            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php if($rule->operator === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="field field-third">
                        <label for="min-<?php echo e($rule->id); ?>">Valor mínimo / comparación</label>
                        <input class="input" id="min-<?php echo e($rule->id); ?>" type="number" step="0.01" name="min_value" value="<?php echo e($rule->min_value); ?>">
                    </div>

                    <div class="field field-third">
                        <label for="max-<?php echo e($rule->id); ?>">Valor máximo</label>
                        <input class="input" id="max-<?php echo e($rule->id); ?>" type="number" step="0.01" name="max_value" value="<?php echo e($rule->max_value); ?>">
                    </div>

                    <div class="field field-third">
                        <label for="comparison-<?php echo e($rule->id); ?>">Valor de texto</label>
                        <input class="input" id="comparison-<?php echo e($rule->id); ?>" type="text" name="comparison_value" value="<?php echo e($rule->comparison_value); ?>">
                    </div>

                    <div class="field field-full">
                        <label for="title-<?php echo e($rule->id); ?>">Título</label>
                        <input class="input" id="title-<?php echo e($rule->id); ?>" type="text" name="title" value="<?php echo e($rule->title); ?>" required>
                    </div>

                    <div class="field field-full">
                        <label for="description-<?php echo e($rule->id); ?>">Descripción</label>
                        <textarea class="textarea" id="description-<?php echo e($rule->id); ?>" name="description" required><?php echo e($rule->description); ?></textarea>
                    </div>

                    <div class="field field-full">
                        <input type="hidden" name="active" value="0">
                        <label class="checkbox-row">
                            <input type="checkbox" name="active" value="1" <?php if($rule->active): echo 'checked'; endif; ?>>
                            <span>Regla activa</span>
                        </label>
                    </div>
                </div>

                <div class="form-actions">
                    <button class="btn btn-primary" type="submit">Guardar regla</button>
                </div>
            </form>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/alert-rules/index.blade.php ENDPATH**/ ?>