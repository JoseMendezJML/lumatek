<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title">Usuarios</h1>
        <p class="page-subtitle">Administración de cuentas, roles y estado de acceso.</p>
    </div>
    <a class="btn btn-primary" href="<?php echo e(route('users.create')); ?>">+ Registrar usuario</a>
</div>

<article class="card">
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Rol</th>
                    <th>Estado</th>
                    <th>Registro</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone ?: '—'); ?></td>
                        <td><span class="badge badge-neutral"><?php echo e($user->role?->name); ?></span></td>
                        <td>
                            <span class="badge <?php echo e($user->active ? 'badge-success' : 'badge-critical'); ?>">
                                <?php echo e($user->active ? 'Activo' : 'Inactivo'); ?>

                            </span>
                        </td>
                        <td><?php echo e($user->created_at->format('d/m/Y')); ?></td>
                        <td>
                            <div class="table-actions">
                                <a class="btn btn-ghost btn-sm" href="<?php echo e(route('users.edit', $user)); ?>">Editar</a>

                                <?php if (! (auth()->user()->is($user))): ?>
                                    <form method="POST" action="<?php echo e(route('users.destroy', $user)); ?>" data-confirm="¿Eliminar a <?php echo e($user->name); ?>?">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" type="submit">Eliminar</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="empty-state">No hay usuarios registrados.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($users->links('partials.pagination')); ?>

</article>

<article class="card" style="margin-top:20px">
    <div class="card-title-row">
        <div>
            <h2 class="card-title">Actividad reciente</h2>
            <p class="card-subtitle">Acciones administrativas y eventos importantes.</p>
        </div>
    </div>

    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Usuario</th>
                    <th>Acción</th>
                    <th>Descripción</th>
                    <th>IP</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->created_at?->format('d/m/Y H:i:s')); ?></td>
                        <td><?php echo e($item->user?->name ?: 'Sistema'); ?></td>
                        <td><span class="badge badge-neutral"><?php echo e($item->action); ?></span></td>
                        <td><?php echo e($item->description); ?></td>
                        <td><?php echo e($item->ip_address ?: '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="empty-state">No hay actividad registrada.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/users/index.blade.php ENDPATH**/ ?>