<?php $__env->startSection('title', 'Editar invernadero'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title">Editar invernadero</h1>
        <p class="page-subtitle"><?php echo e($greenhouse->name); ?></p>
    </div>
</div>

<article class="card">
    <form method="POST" action="<?php echo e(route('greenhouses.update', $greenhouse)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('greenhouses._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/greenhouses/edit.blade.php ENDPATH**/ ?>