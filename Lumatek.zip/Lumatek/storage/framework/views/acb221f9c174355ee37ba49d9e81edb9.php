<?php $__env->startSection('title', 'Riego'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $soil = $reading ? (float) $reading->soil_humidity : 0;
?>

<section
    data-telemetry-dashboard
    data-telemetry-url="<?php echo e(route('api.telemetry.current')); ?>"
    data-poll-seconds="<?php echo e(config('telemetry.poll_seconds', 5)); ?>"
    data-reading-id="<?php echo e($reading?->id ?? 0); ?>"
>
    <div class="page-header">
        <div>
            <h1 class="page-title">Riego</h1>
            <p class="page-subtitle">Programación y ejecución simulada · <?php echo e($greenhouse->name); ?></p>
        </div>
        <span class="data-source-badge">Riego simulado</span>
    </div>

    <div class="dashboard-grid">
        <article class="card span-6">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Estado del riego automático</h2>
                    <p class="card-subtitle">Se activa según humedad, nivel de agua y reglas del invernadero.</p>
                </div>
                <span class="badge <?php echo e($greenhouse->automatic_irrigation ? 'badge-success' : 'badge-neutral'); ?>">
                    <?php echo e($greenhouse->automatic_irrigation ? 'Activo' : 'Desactivado'); ?>

                </span>
            </div>

            <p>
                El riego automático inicia cuando la humedad cae debajo de
                <strong><?php echo e($greenhouse->soil_humidity_min); ?> %</strong> y el depósito conserva más de
                <strong><?php echo e($greenhouse->water_level_min); ?> %</strong>.
            </p>

            <a class="btn btn-secondary" href="<?php echo e(route('control.index')); ?>">Cambiar configuración</a>
        </article>

        <article class="card span-6">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Humedad del suelo actual</h2>
                    <p class="card-subtitle">Última lectura procesada</p>
                </div>
                <span class="data-source-badge">Datos simulados</span>
            </div>

            <div class="big-value" data-reading="soil_humidity"><?php echo e(number_format($soil)); ?> %</div>
            <div class="progress">
                <span data-progress="soil_humidity" style="width:<?php echo e(min(100, max(0, $soil))); ?>%"></span>
            </div>
            <p class="page-subtitle">Nivel recomendado: <?php echo e($greenhouse->soil_humidity_min); ?>–<?php echo e($greenhouse->soil_humidity_max); ?> %</p>
        </article>

        <article class="card span-7">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Programación de riego</h2>
                    <p class="card-subtitle">Horarios de referencia para las pruebas</p>
                </div>
            </div>

            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Horario</th>
                            <th>Duración</th>
                            <th>Días</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($schedule->time)->format('H:i')); ?></td>
                                <td><?php echo e($schedule->duration_minutes); ?> min</td>
                                <td><?php echo e(count($schedule->days ?? []) === 7 ? 'Todos' : count($schedule->days ?? []).' días'); ?></td>
                                <td>
                                    <span class="badge <?php echo e($schedule->active ? 'badge-success' : 'badge-neutral'); ?>">
                                        <?php echo e($schedule->active ? 'Activo' : 'Pausado'); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="table-actions">
                                        <form method="POST" action="<?php echo e(route('irrigation.schedules.toggle', $schedule)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button class="btn btn-ghost btn-sm" type="submit">
                                                <?php echo e($schedule->active ? 'Pausar' : 'Activar'); ?>

                                            </button>
                                        </form>

                                        <form method="POST" action="<?php echo e(route('irrigation.schedules.destroy', $schedule)); ?>" data-confirm="¿Eliminar este horario?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger btn-sm" type="submit">Eliminar</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="empty-state">No hay horarios.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <hr style="border:0;border-top:1px solid var(--line);margin:22px 0">

            <form method="POST" action="<?php echo e(route('irrigation.schedules.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-grid">
                    <div class="field field-third">
                        <label for="schedule-time">Hora</label>
                        <input class="input" id="schedule-time" type="time" name="time" value="<?php echo e(old('time', '08:00')); ?>" required>
                    </div>
                    <div class="field field-third">
                        <label for="schedule-duration">Duración (minutos)</label>
                        <input class="input" id="schedule-duration" type="number" name="duration_minutes" min="1" max="180" value="<?php echo e(old('duration_minutes', 20)); ?>" required>
                    </div>
                    <div class="field field-full">
                        <span class="field-label">Días</span>
                        <div style="display:flex;flex-wrap:wrap;gap:10px 18px">
                            <?php $__currentLoopData = [
                                'monday' => 'Lun',
                                'tuesday' => 'Mar',
                                'wednesday' => 'Mié',
                                'thursday' => 'Jue',
                                'friday' => 'Vie',
                                'saturday' => 'Sáb',
                                'sunday' => 'Dom',
                            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="checkbox-row">
                                    <input type="checkbox" name="days[]" value="<?php echo e($value); ?>" checked>
                                    <span><?php echo e($label); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div class="form-actions">
                    <button class="btn btn-secondary" type="submit">+ Agregar horario</button>
                </div>
            </form>
        </article>

        <article class="card span-5">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Riego manual</h2>
                    <p class="card-subtitle">Prueba controlada sin dispositivo físico</p>
                </div>
                <span class="badge <?php echo e($running ? 'badge-info' : 'badge-neutral'); ?>">
                    <?php echo e($running ? 'En ejecución' : 'Disponible'); ?>

                </span>
            </div>

            <?php if($running): ?>
                <p><strong>Iniciado:</strong> <?php echo e($running->started_at->format('H:i:s')); ?></p>
                <p><strong>Duración:</strong> <?php echo e($running->duration_minutes); ?> minutos</p>
                <p><strong>Humedad inicial:</strong> <?php echo e($running->humidity_before); ?> %</p>

                <form method="POST" action="<?php echo e(route('irrigation.stop')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" style="width:100%" type="submit">Detener riego ahora</button>
                </form>
            <?php else: ?>
                <form method="POST" action="<?php echo e(route('irrigation.start')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="field field-full">
                        <label for="manual-duration">Duración (minutos)</label>
                        <input class="input" id="manual-duration" type="number" name="duration_minutes" min="1" max="180" value="20" required>
                    </div>
                    <button class="btn btn-primary" style="width:100%" type="submit">Iniciar riego ahora</button>
                </form>
            <?php endif; ?>
        </article>

        <article class="card span-12">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Historial de riego</h2>
                    <p class="card-subtitle">Evidencia de pruebas y cambios en la humedad</p>
                </div>
            </div>

            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Tipo</th>
                            <th>Inicio</th>
                            <th>Fin</th>
                            <th>Duración</th>
                            <th>Humedad inicial</th>
                            <th>Humedad final</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($event->started_at->format('d/m/Y')); ?></td>
                                <td><?php echo e(ucfirst($event->type)); ?></td>
                                <td><?php echo e($event->started_at->format('H:i:s')); ?></td>
                                <td><?php echo e($event->ended_at?->format('H:i:s') ?? '—'); ?></td>
                                <td><?php echo e($event->duration_minutes); ?> min</td>
                                <td><?php echo e($event->humidity_before ?? '—'); ?> %</td>
                                <td><?php echo e($event->humidity_after ?? '—'); ?> %</td>
                                <td>
                                    <span class="badge <?php echo e($event->status === 'completed'
                                            ? 'badge-success'
                                            : ($event->status === 'running' ? 'badge-info' : 'badge-neutral')); ?>">
                                        <?php echo e(ucfirst($event->status)); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="8" class="empty-state">No hay riegos registrados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </article>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/irrigation/index.blade.php ENDPATH**/ ?>