<?php $__env->startSection('title', 'Iniciar sesión'); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-card">

    
    <div class="auth-form-panel">

        <div class="auth-brand">
            <span class="brand-mark" aria-hidden="true">🍃</span>

            <span>
                <strong>LUMATEK</strong>
                <small>
                    Tecnología inteligente para un cultivo eficiente.
                </small>
            </span>
        </div>

        <h1 class="auth-title">Iniciar sesión</h1>

        <p class="auth-subtitle">
            Bienvenido de nuevo
        </p>

        
        <?php if(session('status')): ?>
            <div class="alert-flash success">
                <div><?php echo e(session('status')); ?></div>
            </div>
        <?php endif; ?>

        
        <?php if($errors->any()): ?>
            <div class="alert-flash error">
                <div><?php echo e($errors->first()); ?></div>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('login.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="field field-full">
                <label for="email">
                    Correo electrónico
                </label>

                <input
                    class="input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="email"
                    type="email"
                    name="email"
                    value="<?php echo e(old('email')); ?>"
                    placeholder="ejemplo@lumatek.com"
                    autocomplete="email"
                    required
                    autofocus
                >

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error-text">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="field field-full">
                <label for="password">
                    Contraseña
                </label>

                <input
                    class="input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="password"
                    type="password"
                    name="password"
                    placeholder="Ingresa tu contraseña"
                    autocomplete="current-password"
                    required
                >

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error-text">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="auth-links">

                <label class="checkbox-row">
                    <input
                        type="checkbox"
                        name="remember"
                        value="1"
                    >

                    <span>Recordarme</span>
                </label>

                <a href="<?php echo e(route('password.request')); ?>">
                    ¿Olvidaste tu contraseña?
                </a>
            </div>

            <button
                class="btn btn-primary"
                style="width: 100%"
                type="submit"
            >
                Iniciar sesión
            </button>
        </form>

        

    </div>

    
    <div
        class="auth-image-panel"
        role="img"
        aria-label="Invernadero de Lumatek"
    ></div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/auth/login.blade.php ENDPATH**/ ?>