<?php if(session('success')): ?>
    <div class="alert-flash success">
        <div><strong>Listo.</strong> <?php echo e(session('success')); ?></div>
        <button type="button" data-flash-close aria-label="Cerrar">×</button>
    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="alert-flash warning">
        <div><strong>Atención.</strong> <?php echo e(session('warning')); ?></div>
        <button type="button" data-flash-close aria-label="Cerrar">×</button>
    </div>
<?php endif; ?>

<?php if(session('status')): ?>
    <div class="alert-flash success">
        <div><?php echo e(session('status')); ?></div>
        <button type="button" data-flash-close aria-label="Cerrar">×</button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert-flash error">
        <div>
            <strong>Revisa la información:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <button type="button" data-flash-close aria-label="Cerrar">×</button>
    </div>
<?php endif; ?>
<?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/partials/flash.blade.php ENDPATH**/ ?>