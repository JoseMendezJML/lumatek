<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $statuses = app(\App\Services\TelemetryStatusService::class)->metricStatuses($greenhouse, $reading);
    $sourceLabels = [
        'simulation_auto' => 'Simulación automática',
        'simulation_manual' => 'Simulación manual',
        'simulation_scenario' => 'Escenario simulado',
        'iot' => 'IoT',
    ];
    $statusLabels = [
        'normal' => 'Normal',
        'warning' => 'Advertencia',
        'critical' => 'Crítico',
        'unknown' => 'Sin datos',
    ];
    $overallText = match($statuses['overall']) {
        'normal' => 'Todo está funcionando correctamente',
        'warning' => 'Se detectaron condiciones fuera del rango',
        'critical' => 'Se requiere atención inmediata',
        default => 'No hay lecturas disponibles',
    };
?>

<section
    data-telemetry-dashboard
    data-telemetry-url="<?php echo e(route('api.telemetry.current')); ?>"
    data-poll-seconds="<?php echo e(config('telemetry.poll_seconds', 5)); ?>"
    data-reading-id="<?php echo e($reading?->id ?? 0); ?>"
>
    <div class="page-header">
        <div>
            <h1 class="page-title">Inicio</h1>
            <p class="page-subtitle">Bienvenido, <?php echo e(auth()->user()->name); ?> · <?php echo e($greenhouse->name); ?></p>
        </div>

        <div class="header-actions">
            <span class="data-source-badge">
                ◉ <span data-reading-source><?php echo e($sourceLabels[$reading?->source] ?? 'Sin datos'); ?></span>
            </span>
            <span class="badge badge-neutral">
                Actualizado: <span data-reading-time><?php echo e($reading?->recorded_at?->format('d/m/Y H:i:s') ?? '—'); ?></span>
            </span>
        </div>
    </div>

    <div class="metric-grid">
        <article class="metric-card">
            <div class="metric-label">Temperatura</div>
            <div class="metric-value" data-reading="temperature">
                <?php echo e($reading ? number_format((float) $reading->temperature, 1) : '—'); ?> °C
            </div>
            <div class="metric-meta">
                <span class="status-badge status-<?php echo e($statuses['temperature']); ?>" data-status="temperature">
                    <?php echo e($statusLabels[$statuses['temperature']] ?? $statuses['temperature']); ?>

                </span>
                <span>Óptimo <?php echo e($greenhouse->temperature_min); ?>–<?php echo e($greenhouse->temperature_max); ?> °C</span>
            </div>
        </article>

        <article class="metric-card">
            <div class="metric-label">Humedad del suelo</div>
            <div class="metric-value" data-reading="soil_humidity">
                <?php echo e($reading ? number_format((float) $reading->soil_humidity) : '—'); ?> %
            </div>
            <div class="metric-meta">
                <span class="status-badge status-<?php echo e($statuses['soil_humidity']); ?>" data-status="soil_humidity">
                    <?php echo e($statusLabels[$statuses['soil_humidity']] ?? $statuses['soil_humidity']); ?>

                </span>
                <span>Óptimo <?php echo e($greenhouse->soil_humidity_min); ?>–<?php echo e($greenhouse->soil_humidity_max); ?> %</span>
            </div>
        </article>

        <article class="metric-card">
            <div class="metric-label">Humedad ambiental</div>
            <div class="metric-value" data-reading="ambient_humidity">
                <?php echo e($reading ? number_format((float) $reading->ambient_humidity) : '—'); ?> %
            </div>
            <div class="metric-meta">
                <span class="status-badge status-<?php echo e($statuses['ambient_humidity']); ?>" data-status="ambient_humidity">
                    <?php echo e($statusLabels[$statuses['ambient_humidity']] ?? $statuses['ambient_humidity']); ?>

                </span>
                <span>Óptimo <?php echo e($greenhouse->ambient_humidity_min); ?>–<?php echo e($greenhouse->ambient_humidity_max); ?> %</span>
            </div>
        </article>

        <article class="metric-card">
            <div class="metric-label">Luminosidad</div>
            <div class="metric-value" data-reading="luminosity">
                <?php echo e($reading ? number_format((float) $reading->luminosity) : '—'); ?> lux
            </div>
            <div class="metric-meta">
                <span class="status-badge status-<?php echo e($statuses['luminosity']); ?>" data-status="luminosity">
                    <?php echo e($statusLabels[$statuses['luminosity']] ?? $statuses['luminosity']); ?>

                </span>
                <span>Lectura simulada</span>
            </div>
        </article>

        <article class="metric-card">
            <div class="metric-label">Nivel de agua</div>
            <div class="metric-value" data-reading="water_level">
                <?php echo e($reading ? number_format((float) $reading->water_level) : '—'); ?> %
            </div>
            <div class="metric-meta">
                <span class="status-badge status-<?php echo e($statuses['water_level']); ?>" data-status="water_level">
                    <?php echo e($statusLabels[$statuses['water_level']] ?? $statuses['water_level']); ?>

                </span>
                <span>Mínimo <?php echo e($greenhouse->water_level_min); ?> %</span>
            </div>
        </article>
    </div>

    <div class="dashboard-grid">
        <article class="card span-6">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Estado del invernadero</h2>
                    <p class="card-subtitle">Evaluación de la última telemetría recibida</p>
                </div>
                <span class="data-source-badge">Datos simulados</span>
            </div>

            <div class="state-panel <?php echo e($statuses['overall']); ?>" data-overall-state>
                <div class="state-icon">
                    <?php echo e($statuses['overall'] === 'normal' ? '✓' : '!'); ?>

                </div>
                <div>
                    <h3 data-overall-title><?php echo e($overallText); ?></h3>
                    <p>
                        Dispositivo:
                        <strong data-reading="device_status">
                            <?php echo e($reading?->device_status === 'connected' ? 'Conectado' : 'Desconectado'); ?>

                        </strong>
                    </p>
                </div>
            </div>
        </article>

        <article class="card span-6">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Riego automático</h2>
                    <p class="card-subtitle">Control lógico sin dispositivo físico</p>
                </div>
                <span class="badge <?php echo e($greenhouse->automatic_irrigation ? 'badge-success' : 'badge-neutral'); ?>">
                    <?php echo e($greenhouse->automatic_irrigation ? 'Activo' : 'Desactivado'); ?>

                </span>
            </div>

            <div class="state-panel normal">
                <div class="state-icon">💧</div>
                <div>
                    <h3 data-reading="irrigation_status">
                        <?php echo e($activeIrrigation ? 'Regando' : 'Inactivo'); ?>

                    </h3>
                    <p>
                        <?php if($activeIrrigation): ?>
                            Iniciado <?php echo e($activeIrrigation->started_at->diffForHumans()); ?> ·
                            <?php echo e($activeIrrigation->duration_minutes); ?> minutos
                        <?php elseif($nextSchedule): ?>
                            Próximo horario programado: <?php echo e(\Carbon\Carbon::parse($nextSchedule->time)->format('H:i')); ?>

                        <?php else: ?>
                            No hay horarios programados.
                        <?php endif; ?>
                    </p>
                    <a class="btn btn-secondary btn-sm" href="<?php echo e(route('irrigation.index')); ?>" style="margin-top:12px">
                        Abrir control de riego
                    </a>
                </div>
            </div>
        </article>

        <article class="card span-7">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Últimas alertas</h2>
                    <p class="card-subtitle">Condiciones detectadas por las reglas configurables</p>
                </div>
                <a class="btn btn-ghost btn-sm" href="<?php echo e(route('alerts.index')); ?>">Ver todas</a>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $recentAlerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="alert-row">
                    <span class="alert-dot <?php echo e($alert->severity); ?>"></span>
                    <div>
                        <strong><?php echo e($alert->title); ?></strong>
                        <small><?php echo e($alert->description); ?></small>
                    </div>
                    <time><?php echo e($alert->last_triggered_at->format('H:i')); ?></time>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state">No se han generado alertas.</div>
            <?php endif; ?>
        </article>

        <article class="card span-5">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Pronóstico del clima</h2>
                    <p class="card-subtitle">Integración opcional para una fase posterior</p>
                </div>
                <span class="badge badge-neutral">No conectado</span>
            </div>

            <div class="weather-panel">
                <div class="weather-main">
                    <span class="weather-icon">☁</span>
                    <div>
                        <div class="weather-temp">— °C</div>
                        <div>API meteorológica pendiente</div>
                    </div>
                </div>
                <div class="weather-details">
                    <div>Humedad: —</div>
                    <div>Viento: —</div>
                </div>
            </div>
        </article>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/dashboard/index.blade.php ENDPATH**/ ?>