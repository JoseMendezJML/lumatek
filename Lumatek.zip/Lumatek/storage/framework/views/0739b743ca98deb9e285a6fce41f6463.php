<?php
    $layoutGreenhouses = \App\Models\Greenhouse::query()->orderBy('name')->get();
    $layoutGreenhouseId = session('greenhouse_id') ?: $layoutGreenhouses->first()?->id;
    $activeAlertCount = \App\Models\Alert::query()
        ->when($layoutGreenhouseId, fn ($query) => $query->where('greenhouse_id', $layoutGreenhouseId))
        ->whereIn('status', ['new', 'viewed'])
        ->count();
?>

<header class="topbar">
    <div class="topbar-left">
        <button type="button" class="menu-button" data-menu-toggle aria-label="Abrir menú">☰</button>

        <?php if($layoutGreenhouses->isNotEmpty()): ?>
            <form class="greenhouse-selector" method="GET" action="<?php echo e(route('dashboard')); ?>">
                <label for="top-greenhouse">Invernadero:</label>
                <select id="top-greenhouse" name="greenhouse_id">
                    <?php $__currentLoopData = $layoutGreenhouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if((int) $layoutGreenhouseId === $item->id): echo 'selected'; endif; ?>>
                            <?php echo e($item->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-ghost btn-sm" type="submit">Cambiar</button>
            </form>
        <?php endif; ?>
    </div>

    <div class="topbar-right">
        <a class="notification-link" href="<?php echo e(route('alerts.index')); ?>" aria-label="Alertas activas">
            🔔
            <span class="notification-count" data-alert-count @hidden($activeAlertCount < 1)>
                <?php echo e($activeAlertCount); ?>

            </span>
        </a>

        <div class="user-chip">
            <span class="user-avatar"><?php echo e(mb_strtoupper(mb_substr(auth()->user()->name, 0, 1))); ?></span>
            <span class="user-meta">
                <strong><?php echo e(auth()->user()->name); ?></strong>
                <span><?php echo e(auth()->user()->role?->name); ?></span>
            </span>
        </div>
    </div>
</header>
<?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/partials/topbar.blade.php ENDPATH**/ ?>