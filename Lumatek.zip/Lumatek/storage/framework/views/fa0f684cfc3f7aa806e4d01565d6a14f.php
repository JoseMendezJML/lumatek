<?php $__env->startSection('title', 'Registrar invernadero'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title">Registrar invernadero</h1>
        <p class="page-subtitle">Configura su información y rangos de operación.</p>
    </div>
</div>

<article class="card">
    <form method="POST" action="<?php echo e(route('greenhouses.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('greenhouses._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/greenhouses/create.blade.php ENDPATH**/ ?>