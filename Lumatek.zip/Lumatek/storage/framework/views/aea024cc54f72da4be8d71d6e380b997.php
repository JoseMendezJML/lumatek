<?php $__env->startSection('title', 'Alertas'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title">Alertas</h1>
        <p class="page-subtitle"><?php echo e($greenhouse->name); ?> · detecciones generadas por telemetría</p>
    </div>
    <span class="data-source-badge">Datos simulados</span>
</div>

<div class="tabs">
    <a class="tab <?php echo e($severity === '' ? 'active' : ''); ?>" href="<?php echo e(route('alerts.index', ['status' => $status ?: null])); ?>">Todas</a>
    <a class="tab <?php echo e($severity === 'critical' ? 'active' : ''); ?>" href="<?php echo e(route('alerts.index', ['severity' => 'critical', 'status' => $status ?: null])); ?>">Críticas</a>
    <a class="tab <?php echo e($severity === 'warning' ? 'active' : ''); ?>" href="<?php echo e(route('alerts.index', ['severity' => 'warning', 'status' => $status ?: null])); ?>">Advertencias</a>
    <a class="tab <?php echo e($severity === 'info' ? 'active' : ''); ?>" href="<?php echo e(route('alerts.index', ['severity' => 'info', 'status' => $status ?: null])); ?>">Información</a>
</div>

<div class="card" style="margin-bottom:18px">
    <form class="form-grid" method="GET" action="<?php echo e(route('alerts.index')); ?>">
        <input type="hidden" name="severity" value="<?php echo e($severity); ?>">
        <div class="field field-third">
            <label for="status">Estado</label>
            <select class="select" id="status" name="status">
                <option value="">Todos</option>
                <option value="new" <?php if($status === 'new'): echo 'selected'; endif; ?>>Nuevas</option>
                <option value="viewed" <?php if($status === 'viewed'): echo 'selected'; endif; ?>>Vistas</option>
                <option value="resolved" <?php if($status === 'resolved'): echo 'selected'; endif; ?>>Resueltas</option>
            </select>
        </div>
        <div class="field field-third" style="display:flex;align-items:end;gap:8px">
            <button class="btn btn-primary" type="submit">Filtrar</button>
            <a class="btn btn-ghost" href="<?php echo e(route('alerts.index')); ?>">Limpiar</a>
        </div>
    </form>
</div>

<?php $__empty_1 = true; $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
        $icon = match($alert->severity) {
            'critical' => '🌡',
            'warning' => '⚠',
            default => 'ℹ',
        };
    ?>

    <article class="alert-card <?php echo e($alert->severity); ?>">
        <div class="alert-symbol"><?php echo e($icon); ?></div>

        <div>
            <h3><?php echo e($alert->title); ?></h3>
            <p><?php echo e($alert->description); ?></p>
            <div class="alert-card-meta">
                <span><strong>Invernadero:</strong> <?php echo e($alert->greenhouse->name); ?></span>
                <span><strong>Variable:</strong> <?php echo e(str_replace('_', ' ', $alert->variable)); ?></span>
                <?php if($alert->value !== null): ?>
                    <span><strong>Valor:</strong> <?php echo e($alert->value); ?></span>
                <?php endif; ?>
                <span><strong>Origen:</strong> <?php echo e(str_replace('_', ' ', $alert->source)); ?></span>
                <span><strong>Actualizada:</strong> <?php echo e($alert->last_triggered_at->format('d/m/Y H:i:s')); ?></span>
            </div>
        </div>

        <div class="alert-card-actions">
            <span class="badge <?php echo e($alert->status === 'resolved'
                    ? 'badge-success'
                    : ($alert->status === 'viewed' ? 'badge-neutral' : 'badge-info')); ?>">
                <?php echo e(ucfirst($alert->status)); ?>

            </span>

            <?php if($alert->status === 'new'): ?>
                <form method="POST" action="<?php echo e(route('alerts.viewed', $alert)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button class="btn btn-ghost btn-sm" type="submit">Marcar vista</button>
                </form>
            <?php endif; ?>

            <?php if($alert->status !== 'resolved'): ?>
                <form method="POST" action="<?php echo e(route('alerts.resolve', $alert)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button class="btn btn-primary btn-sm" type="submit">Resolver</button>
                </form>
            <?php endif; ?>
        </div>
    </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="card empty-state">No hay alertas con los filtros seleccionados.</div>
<?php endif; ?>

<?php echo e($alerts->links('partials.pagination')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/alerts/index.blade.php ENDPATH**/ ?>