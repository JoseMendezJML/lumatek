<?php $__env->startSection('title', 'Simulador'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $reading ??= null;
    $sourceLabels = [
        'simulation_auto' => 'Automática',
        'simulation_manual' => 'Manual',
        'simulation_scenario' => 'Escenario',
        'iot' => 'IoT',
    ];
?>

<section
    data-telemetry-dashboard
    data-telemetry-url="<?php echo e(route('api.telemetry.current')); ?>"
    data-poll-seconds="<?php echo e(config('telemetry.poll_seconds', 5)); ?>"
    data-reading-id="<?php echo e($reading?->id ?? 0); ?>"
>
    <div class="page-header">
        <div>
            <h1 class="page-title">Simulador de telemetría</h1>
            <p class="page-subtitle">
                Modifica lecturas sintéticas para probar dashboard, alertas, riego e informes.
            </p>
        </div>

        <div class="header-actions">
            <span class="data-source-badge">Datos simulados</span>
            <span class="badge badge-neutral">
                Sin sensores físicos
            </span>
        </div>
    </div>

    <div class="dashboard-grid">
        <article class="card span-8">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Simulación manual</h2>
                    <p class="card-subtitle">Los valores enviados se guardan como una lectura real y activan las reglas de negocio.</p>
                </div>
                <span class="badge badge-info">simulation_manual</span>
            </div>

            <form method="POST" action="<?php echo e(route('simulator.manual')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-grid">
                    <div class="field">
                        <label for="temperature">Temperatura (°C)</label>
                        <div class="range-pair">
                            <input
                                type="range"
                                min="-20"
                                max="80"
                                step="0.1"
                                value="<?php echo e(old('temperature', $reading?->temperature ?? 28.5)); ?>"
                                data-range-target="temperature"
                            >
                            <input
                                class="input"
                                id="temperature"
                                type="number"
                                name="temperature"
                                min="-20"
                                max="80"
                                step="0.1"
                                value="<?php echo e(old('temperature', $reading?->temperature ?? 28.5)); ?>"
                                required
                            >
                        </div>
                    </div>

                    <div class="field">
                        <label for="soil_humidity">Humedad del suelo (%)</label>
                        <div class="range-pair">
                            <input
                                type="range"
                                min="0"
                                max="100"
                                step="1"
                                value="<?php echo e(old('soil_humidity', $reading?->soil_humidity ?? 45)); ?>"
                                data-range-target="soil_humidity"
                            >
                            <input
                                class="input"
                                id="soil_humidity"
                                type="number"
                                name="soil_humidity"
                                min="0"
                                max="100"
                                step="0.1"
                                value="<?php echo e(old('soil_humidity', $reading?->soil_humidity ?? 45)); ?>"
                                required
                            >
                        </div>
                    </div>

                    <div class="field">
                        <label for="ambient_humidity">Humedad ambiental (%)</label>
                        <div class="range-pair">
                            <input
                                type="range"
                                min="0"
                                max="100"
                                step="1"
                                value="<?php echo e(old('ambient_humidity', $reading?->ambient_humidity ?? 65)); ?>"
                                data-range-target="ambient_humidity"
                            >
                            <input
                                class="input"
                                id="ambient_humidity"
                                type="number"
                                name="ambient_humidity"
                                min="0"
                                max="100"
                                step="0.1"
                                value="<?php echo e(old('ambient_humidity', $reading?->ambient_humidity ?? 65)); ?>"
                                required
                            >
                        </div>
                    </div>

                    <div class="field">
                        <label for="luminosity">Luminosidad (lux)</label>
                        <div class="range-pair">
                            <input
                                type="range"
                                min="0"
                                max="100000"
                                step="100"
                                value="<?php echo e(old('luminosity', $reading?->luminosity ?? 1200)); ?>"
                                data-range-target="luminosity"
                            >
                            <input
                                class="input"
                                id="luminosity"
                                type="number"
                                name="luminosity"
                                min="0"
                                max="100000"
                                step="1"
                                value="<?php echo e(old('luminosity', $reading?->luminosity ?? 1200)); ?>"
                                required
                            >
                        </div>
                    </div>

                    <div class="field">
                        <label for="water_level">Nivel del depósito (%)</label>
                        <div class="range-pair">
                            <input
                                type="range"
                                min="0"
                                max="100"
                                step="1"
                                value="<?php echo e(old('water_level', $reading?->water_level ?? 80)); ?>"
                                data-range-target="water_level"
                            >
                            <input
                                class="input"
                                id="water_level"
                                type="number"
                                name="water_level"
                                min="0"
                                max="100"
                                step="0.1"
                                value="<?php echo e(old('water_level', $reading?->water_level ?? 80)); ?>"
                                required
                            >
                        </div>
                    </div>

                    <div class="field">
                        <label for="irrigation_status">Estado del riego</label>
                        <select class="select" id="irrigation_status" name="irrigation_status" required>
                            <option value="inactive" <?php if(old('irrigation_status', $reading?->irrigation_status) === 'inactive'): echo 'selected'; endif; ?>>Inactivo</option>
                            <option value="active" <?php if(old('irrigation_status', $reading?->irrigation_status) === 'active'): echo 'selected'; endif; ?>>Activo</option>
                            <option value="fault" <?php if(old('irrigation_status', $reading?->irrigation_status) === 'fault'): echo 'selected'; endif; ?>>Falla</option>
                        </select>
                    </div>

                    <div class="field">
                        <label for="device_status">Estado de conexión</label>
                        <select class="select" id="device_status" name="device_status" required>
                            <option value="connected" <?php if(old('device_status', $reading?->device_status) === 'connected'): echo 'selected'; endif; ?>>Conectado</option>
                            <option value="disconnected" <?php if(old('device_status', $reading?->device_status) === 'disconnected'): echo 'selected'; endif; ?>>Desconectado</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions">
                    <button class="btn btn-ghost" type="submit" form="simulator-reset-form">Restaurar valores normales</button>
                    <button class="btn btn-primary" type="submit">Enviar lectura</button>
                </div>
            </form>

            <form id="simulator-reset-form" method="POST" action="<?php echo e(route('simulator.reset')); ?>">
                <?php echo csrf_field(); ?>
            </form>
        </article>

        <article class="card span-4">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Simulación automática</h2>
                    <p class="card-subtitle">Genera pequeñas variaciones con cada ciclo de actualización.</p>
                </div>
            </div>

            <div class="simulation-status" style="margin-bottom:18px">
                <span class="pulse <?php echo e($control->status); ?>"></span>
                <div>
                    <strong><?php echo e(ucfirst($control->status)); ?></strong>
                    <div class="help-text">
                        Intervalo: <?php echo e($control->interval_seconds); ?> s · Intensidad: <?php echo e($control->variation_intensity); ?>

                    </div>
                </div>
            </div>

            <form method="POST" action="<?php echo e(route('simulator.start')); ?>">
                <?php echo csrf_field(); ?>

                <div class="field field-full">
                    <label for="interval_seconds">Intervalo de generación</label>
                    <select class="select" id="interval_seconds" name="interval_seconds">
                        <option value="5" <?php if($control->interval_seconds === 5): echo 'selected'; endif; ?>>5 segundos</option>
                        <option value="10" <?php if($control->interval_seconds === 10): echo 'selected'; endif; ?>>10 segundos</option>
                        <option value="30" <?php if($control->interval_seconds === 30): echo 'selected'; endif; ?>>30 segundos</option>
                        <option value="60" <?php if($control->interval_seconds === 60): echo 'selected'; endif; ?>>1 minuto</option>
                    </select>
                </div>

                <div class="field field-full" style="margin-top:14px">
                    <label for="variation_intensity">Intensidad de variación</label>
                    <select class="select" id="variation_intensity" name="variation_intensity">
                        <option value="0.5" <?php if((float) $control->variation_intensity === 0.5): echo 'selected'; endif; ?>>Baja</option>
                        <option value="1" <?php if((float) $control->variation_intensity === 1.0): echo 'selected'; endif; ?>>Normal</option>
                        <option value="2" <?php if((float) $control->variation_intensity === 2.0): echo 'selected'; endif; ?>>Alta</option>
                        <option value="4" <?php if((float) $control->variation_intensity === 4.0): echo 'selected'; endif; ?>>Extrema</option>
                    </select>
                </div>

                <button class="btn btn-primary" style="width:100%;margin-top:16px" type="submit">
                    Iniciar o reanudar
                </button>
            </form>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
                <form method="POST" action="<?php echo e(route('simulator.pause')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-warning" style="width:100%" type="submit">Pausar</button>
                </form>
                <form method="POST" action="<?php echo e(route('simulator.stop')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" style="width:100%" type="submit">Detener</button>
                </form>
            </div>

            <div class="alert-flash warning" style="margin:18px 0 0">
                <div>
                    El motor automático avanza cuando una vista consulta
                    <code>/api/telemetry/current</code>. No requiere cron para esta demostración.
                </div>
            </div>
        </article>

        <article class="card span-12">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Escenarios de prueba</h2>
                    <p class="card-subtitle">Casos predefinidos para ejecutar pruebas de aceptación rápidamente.</p>
                </div>
                <span class="badge badge-info">simulation_scenario</span>
            </div>

            <div class="scenario-grid">
                <?php $__currentLoopData = $scenarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scenario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="scenario-card">
                        <div>
                            <h3><?php echo e($scenario->name); ?></h3>
                            <p><?php echo e($scenario->description); ?></p>
                        </div>
                        <form method="POST" action="<?php echo e(route('simulator.scenario', $scenario)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-secondary" style="width:100%" type="submit">
                                Ejecutar escenario
                            </button>
                        </form>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </article>

        <article class="card span-12">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Últimas lecturas</h2>
                    <p class="card-subtitle">Registros que reciben las demás vistas del sistema.</p>
                </div>
                <span class="badge badge-neutral">
                    Actual: <span data-reading-source><?php echo e($sourceLabels[$reading?->source] ?? '—'); ?></span>
                </span>
            </div>

            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Temperatura</th>
                            <th>Suelo</th>
                            <th>Ambiente</th>
                            <th>Luz</th>
                            <th>Agua</th>
                            <th>Riego</th>
                            <th>Origen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($item->recorded_at->format('d/m/Y H:i:s')); ?></td>
                                <td><?php echo e($item->temperature); ?> °C</td>
                                <td><?php echo e($item->soil_humidity); ?> %</td>
                                <td><?php echo e($item->ambient_humidity); ?> %</td>
                                <td><?php echo e($item->luminosity); ?> lux</td>
                                <td><?php echo e($item->water_level); ?> %</td>
                                <td><?php echo e(ucfirst($item->irrigation_status)); ?></td>
                                <td><span class="badge badge-neutral"><?php echo e($sourceLabels[$item->source] ?? $item->source); ?></span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="8" class="empty-state">No existen lecturas.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </article>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/simulator/index.blade.php ENDPATH**/ ?>