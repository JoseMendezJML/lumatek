<aside class="sidebar" aria-label="Menú principal">
    <a href="<?php echo e(route('dashboard')); ?>" class="brand">
        <span class="brand-mark" aria-hidden="true">🍃</span>
        <span>
            <span class="brand-name">LUMATEK</span>
            <span class="brand-subtitle">Cultivo inteligente</span>
        </span>
    </a>

    <nav class="sidebar-nav">
        <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
            <span class="nav-icon">⌂</span>
            <span>Inicio</span>
        </a>

        <a class="nav-link <?php echo e(request()->routeIs('control.*') ? 'active' : ''); ?>" href="<?php echo e(route('control.index')); ?>">
            <span class="nav-icon">◷</span>
            <span>Control</span>
        </a>

        <a class="nav-link <?php echo e(request()->routeIs('alerts.*') ? 'active' : ''); ?>" href="<?php echo e(route('alerts.index')); ?>">
            <span class="nav-icon">♢</span>
            <span>Alertas</span>
        </a>

        <a class="nav-link <?php echo e(request()->routeIs('irrigation.*') ? 'active' : ''); ?>" href="<?php echo e(route('irrigation.index')); ?>">
            <span class="nav-icon">💧</span>
            <span>Riego</span>
        </a>

        <a class="nav-link <?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>" href="<?php echo e(route('reports.index')); ?>">
            <span class="nav-icon">▤</span>
            <span>Reportes</span>
        </a>

        <?php if(auth()->user()->isAdmin()): ?>
            <a class="nav-link <?php echo e(request()->routeIs('simulator.*') ? 'active' : ''); ?>" href="<?php echo e(route('simulator.index')); ?>">
                <span class="nav-icon">⚙</span>
                <span>Simulador</span>
            </a>

            <a class="nav-link <?php echo e(request()->routeIs('greenhouses.*') ? 'active' : ''); ?>" href="<?php echo e(route('greenhouses.index')); ?>">
                <span class="nav-icon">▱</span>
                <span>Invernaderos</span>
            </a>

            <a class="nav-link <?php echo e(request()->routeIs('alert-rules.*') ? 'active' : ''); ?>" href="<?php echo e(route('alert-rules.index')); ?>">
                <span class="nav-icon">≋</span>
                <span>Reglas</span>
            </a>

            <a class="nav-link <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">
                <span class="nav-icon">♙</span>
                <span>Usuarios</span>
            </a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="nav-link logout-button" type="submit">
                <span class="nav-icon">⇥</span>
                <span>Cerrar sesión</span>
            </button>
        </form>
    </div>
</aside>
<?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>