<?php $__env->startSection('title', 'Control'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $soil = $reading ? (float) $reading->soil_humidity : 0;
?>

<section
    data-telemetry-dashboard
    data-telemetry-url="<?php echo e(route('api.telemetry.current')); ?>"
    data-poll-seconds="<?php echo e(config('telemetry.poll_seconds', 5)); ?>"
    data-reading-id="<?php echo e($reading?->id ?? 0); ?>"
>
    <div class="page-header">
        <div>
            <h1 class="page-title">Control</h1>
            <p class="page-subtitle"><?php echo e($greenhouse->name); ?> · operación simulada</p>
        </div>
        <span class="data-source-badge">Datos simulados</span>
    </div>

    <div class="control-hero">
        <article class="card">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Riego automático</h2>
                    <p class="card-subtitle">
                        El sistema inicia un riego simulado cuando la humedad está debajo de
                        <?php echo e($greenhouse->soil_humidity_min); ?> % y hay suficiente agua.
                    </p>
                </div>

                <form method="POST" action="<?php echo e(route('control.automatic')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button class="btn <?php echo e($greenhouse->automatic_irrigation ? 'btn-primary' : 'btn-ghost'); ?>" type="submit">
                        <?php echo e($greenhouse->automatic_irrigation ? 'Activado' : 'Desactivado'); ?>

                    </button>
                </form>
            </div>

            <hr style="border:0;border-top:1px solid var(--line);margin:20px 0">

            <h3 style="margin:0">Humedad del suelo actual</h3>
            <div class="big-value" data-reading="soil_humidity"><?php echo e(number_format($soil)); ?> %</div>
            <div class="progress" aria-label="Humedad del suelo">
                <span data-progress="soil_humidity" style="width:<?php echo e(min(100, max(0, $soil))); ?>%"></span>
            </div>
            <p class="page-subtitle">Rango ideal: <?php echo e($greenhouse->soil_humidity_min); ?> % – <?php echo e($greenhouse->soil_humidity_max); ?> %</p>
        </article>

        <article class="card">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Estado del riego</h2>
                    <p class="card-subtitle">Ejecución lógica, sin activar una bomba física</p>
                </div>
                <span class="badge <?php echo e($running ? 'badge-success' : 'badge-neutral'); ?>">
                    <?php echo e($running ? 'Regando' : 'Inactivo'); ?>

                </span>
            </div>

            <?php if($running): ?>
                <p><strong>Inicio:</strong> <?php echo e($running->started_at->format('d/m/Y H:i:s')); ?></p>
                <p><strong>Duración programada:</strong> <?php echo e($running->duration_minutes); ?> min</p>
                <p><strong>Origen:</strong> <?php echo e($running->type === 'automatic' ? 'Automático' : 'Manual'); ?></p>

                <form method="POST" action="<?php echo e(route('irrigation.stop')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" type="submit">Detener riego simulado</button>
                </form>
            <?php else: ?>
                <form method="POST" action="<?php echo e(route('irrigation.start')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="field field-full">
                        <label for="control-duration">Duración del riego</label>
                        <select class="select" id="control-duration" name="duration_minutes">
                            <option value="5">5 minutos</option>
                            <option value="10">10 minutos</option>
                            <option value="20" selected>20 minutos</option>
                            <option value="30">30 minutos</option>
                        </select>
                    </div>
                    <button class="btn btn-primary" type="submit">Regar ahora manualmente</button>
                </form>
            <?php endif; ?>
        </article>
    </div>

    <div class="dashboard-grid" style="margin-top:18px">
        <article class="card span-5">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Programa de riego</h2>
                    <p class="card-subtitle">Horarios configurados para el invernadero</p>
                </div>
                <a class="btn btn-ghost btn-sm" href="<?php echo e(route('irrigation.index')); ?>">Administrar</a>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="alert-row">
                    <span class="alert-dot <?php echo e($schedule->active ? 'info' : ''); ?>" style="<?php echo e(!$schedule->active ? 'background:#9ca3af' : ''); ?>"></span>
                    <div>
                        <strong><?php echo e(\Carbon\Carbon::parse($schedule->time)->format('H:i')); ?></strong>
                        <small>Duración estimada: <?php echo e($schedule->duration_minutes); ?> min</small>
                    </div>
                    <span class="badge <?php echo e($schedule->active ? 'badge-success' : 'badge-neutral'); ?>">
                        <?php echo e($schedule->active ? 'Activo' : 'Pausado'); ?>

                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state">No hay horarios programados.</div>
            <?php endif; ?>
        </article>

        <article class="card span-7">
            <div class="card-title-row">
                <div>
                    <h2 class="card-title">Historial reciente</h2>
                    <p class="card-subtitle">Eventos de riego simulados</p>
                </div>
            </div>

            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Inicio</th>
                            <th>Duración</th>
                            <th>Tipo</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($event->started_at->format('d/m/Y')); ?></td>
                                <td><?php echo e($event->started_at->format('H:i')); ?></td>
                                <td><?php echo e($event->duration_minutes); ?> min</td>
                                <td><?php echo e(ucfirst($event->type)); ?></td>
                                <td>
                                    <span class="badge <?php echo e($event->status === 'completed'
                                            ? 'badge-success'
                                            : ($event->status === 'running' ? 'badge-info' : 'badge-neutral')); ?>">
                                        <?php echo e(ucfirst($event->status)); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="empty-state">No hay eventos registrados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </article>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/control/index.blade.php ENDPATH**/ ?>