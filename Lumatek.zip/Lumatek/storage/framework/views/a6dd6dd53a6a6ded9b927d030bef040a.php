<?php $__env->startSection('title', 'Reportes'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $period = request('period', 'week');
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Reportes</h1>
        <p class="page-subtitle"><?php echo e($greenhouse->name); ?> · información almacenada en la base de datos</p>
    </div>

    <div class="header-actions">
        <a
            class="btn btn-primary"
            href="<?php echo e(route('reports.print', request()->query())); ?>"
            target="_blank"
        >
            Imprimir / Guardar PDF
        </a>
    </div>
</div>

<article class="card" style="margin-bottom:20px">
    <form method="GET" action="<?php echo e(route('reports.index')); ?>">
        <div class="form-grid">
            <div class="field field-quarter">
                <label for="period">Periodo</label>
                <select class="select" id="period" name="period">
                    <option value="day" <?php if($period === 'day'): echo 'selected'; endif; ?>>Hoy</option>
                    <option value="week" <?php if($period === 'week'): echo 'selected'; endif; ?>>Últimos 7 días</option>
                    <option value="month" <?php if($period === 'month'): echo 'selected'; endif; ?>>Mes actual</option>
                    <option value="custom" <?php if($period === 'custom'): echo 'selected'; endif; ?>>Personalizado</option>
                </select>
            </div>

            <div class="field field-quarter">
                <label for="from">Desde</label>
                <input class="input" id="from" type="date" name="from" value="<?php echo e(request('from', $from->toDateString())); ?>">
            </div>

            <div class="field field-quarter">
                <label for="to">Hasta</label>
                <input class="input" id="to" type="date" name="to" value="<?php echo e(request('to', $to->toDateString())); ?>">
            </div>

            <div class="field field-quarter">
                <label for="source">Origen</label>
                <select class="select" id="source" name="source">
                    <option value="">Todos</option>
                    <option value="simulation_manual" <?php if($source === 'simulation_manual'): echo 'selected'; endif; ?>>Simulación manual</option>
                    <option value="simulation_auto" <?php if($source === 'simulation_auto'): echo 'selected'; endif; ?>>Simulación automática</option>
                    <option value="simulation_scenario" <?php if($source === 'simulation_scenario'): echo 'selected'; endif; ?>>Escenario</option>
                    <option value="iot" <?php if($source === 'iot'): echo 'selected'; endif; ?>>IoT</option>
                </select>
            </div>

            <div class="field field-quarter">
                <label for="variable">Variable de alerta</label>
                <select class="select" id="variable" name="variable">
                    <option value="">Todas</option>
                    <option value="temperature" <?php if($variable === 'temperature'): echo 'selected'; endif; ?>>Temperatura</option>
                    <option value="soil_humidity" <?php if($variable === 'soil_humidity'): echo 'selected'; endif; ?>>Humedad del suelo</option>
                    <option value="ambient_humidity" <?php if($variable === 'ambient_humidity'): echo 'selected'; endif; ?>>Humedad ambiental</option>
                    <option value="water_level" <?php if($variable === 'water_level'): echo 'selected'; endif; ?>>Nivel de agua</option>
                    <option value="irrigation_status" <?php if($variable === 'irrigation_status'): echo 'selected'; endif; ?>>Estado del riego</option>
                    <option value="device_status" <?php if($variable === 'device_status'): echo 'selected'; endif; ?>>Conexión</option>
                </select>
            </div>

            <div class="field field-quarter">
                <label for="severity">Tipo de alerta</label>
                <select class="select" id="severity" name="severity">
                    <option value="">Todas</option>
                    <option value="info" <?php if($severity === 'info'): echo 'selected'; endif; ?>>Información</option>
                    <option value="warning" <?php if($severity === 'warning'): echo 'selected'; endif; ?>>Advertencia</option>
                    <option value="critical" <?php if($severity === 'critical'): echo 'selected'; endif; ?>>Crítica</option>
                </select>
            </div>

            <div class="field field-quarter" style="display:flex;align-items:end">
                <button class="btn btn-primary" style="width:100%" type="submit">Generar reporte</button>
            </div>
        </div>
    </form>
</article>

<div class="report-metrics">
    <div class="report-stat">
        Lecturas procesadas
        <strong><?php echo e(number_format((int) ($stats->readings_count ?? 0))); ?></strong>
    </div>
    <div class="report-stat">
        Temperatura promedio
        <strong><?php echo e(number_format((float) ($stats->temperature_avg ?? 0), 1)); ?> °C</strong>
    </div>
    <div class="report-stat">
        Humedad del suelo promedio
        <strong><?php echo e(number_format((float) ($stats->soil_humidity_avg ?? 0), 1)); ?> %</strong>
    </div>
    <div class="report-stat">
        Riegos simulados
        <strong><?php echo e(number_format($irrigationSummary['count'])); ?></strong>
    </div>
</div>

<div class="dashboard-grid">
    <article class="card span-6">
        <div class="card-title-row">
            <div>
                <h2 class="card-title">Resumen de telemetría</h2>
                <p class="card-subtitle"><?php echo e($from->format('d/m/Y')); ?> al <?php echo e($to->format('d/m/Y')); ?></p>
            </div>
            <span class="data-source-badge">Datos simulados</span>
        </div>

        <div class="table-wrap">
            <table class="table">
                <tbody>
                    <tr>
                        <th>Temperatura mínima</th>
                        <td><?php echo e(number_format((float) ($stats->temperature_min ?? 0), 1)); ?> °C</td>
                    </tr>
                    <tr>
                        <th>Temperatura máxima</th>
                        <td><?php echo e(number_format((float) ($stats->temperature_max ?? 0), 1)); ?> °C</td>
                    </tr>
                    <tr>
                        <th>Humedad del suelo mínima</th>
                        <td><?php echo e(number_format((float) ($stats->soil_humidity_min ?? 0), 1)); ?> %</td>
                    </tr>
                    <tr>
                        <th>Humedad del suelo máxima</th>
                        <td><?php echo e(number_format((float) ($stats->soil_humidity_max ?? 0), 1)); ?> %</td>
                    </tr>
                    <tr>
                        <th>Humedad ambiental promedio</th>
                        <td><?php echo e(number_format((float) ($stats->ambient_humidity_avg ?? 0), 1)); ?> %</td>
                    </tr>
                    <tr>
                        <th>Luminosidad promedio</th>
                        <td><?php echo e(number_format((float) ($stats->luminosity_avg ?? 0), 0)); ?> lux</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </article>

    <article class="card span-6">
        <div class="card-title-row">
            <div>
                <h2 class="card-title">Actividad del periodo</h2>
                <p class="card-subtitle">Alertas, riegos y origen de lecturas</p>
            </div>
        </div>

        <div class="table-wrap">
            <table class="table">
                <tbody>
                    <tr>
                        <th>Alertas generadas</th>
                        <td><?php echo e($alertSummary['generated']); ?></td>
                    </tr>
                    <tr>
                        <th>Alertas críticas</th>
                        <td><?php echo e($alertSummary['critical']); ?></td>
                    </tr>
                    <tr>
                        <th>Alertas resueltas</th>
                        <td><?php echo e($alertSummary['resolved']); ?></td>
                    </tr>
                    <tr>
                        <th>Minutos de riego</th>
                        <td><?php echo e($irrigationSummary['minutes']); ?> min</td>
                    </tr>
                    <tr>
                        <th>Lecturas manuales</th>
                        <td><?php echo e((int) ($stats->manual_count ?? 0)); ?></td>
                    </tr>
                    <tr>
                        <th>Lecturas automáticas</th>
                        <td><?php echo e((int) ($stats->auto_count ?? 0)); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </article>

    <article class="card span-12">
        <div class="card-title-row">
            <div>
                <h2 class="card-title">Detalle de lecturas</h2>
                <p class="card-subtitle">Se muestran hasta 100 registros del periodo.</p>
            </div>
        </div>

        <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Temperatura</th>
                        <th>Suelo</th>
                        <th>Ambiente</th>
                        <th>Luz</th>
                        <th>Agua</th>
                        <th>Riego</th>
                        <th>Origen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $readings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($reading->recorded_at->format('d/m/Y H:i:s')); ?></td>
                            <td><?php echo e($reading->temperature); ?> °C</td>
                            <td><?php echo e($reading->soil_humidity); ?> %</td>
                            <td><?php echo e($reading->ambient_humidity); ?> %</td>
                            <td><?php echo e($reading->luminosity); ?> lux</td>
                            <td><?php echo e($reading->water_level); ?> %</td>
                            <td><?php echo e(ucfirst($reading->irrigation_status)); ?></td>
                            <td><?php echo e(str_replace('_', ' ', $reading->source)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="8" class="empty-state">No existen lecturas en este periodo.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </article>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/judas/Desktop/Lumatek/lumatekwebapp/resources/views/reports/index.blade.php ENDPATH**/ ?>